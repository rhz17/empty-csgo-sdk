#pragma once

#include "variables.h"

namespace handling {
	namespace utils {
		sdk::classes::base_general* Entity = nullptr;
		sdk::classes::user_cmd* Command = nullptr;
	};
};