#pragma once

#include "../sdk.h"

namespace sdk {
	namespace interfaces {
		class client_mode {
		public:

		};
	};
};