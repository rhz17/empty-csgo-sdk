#pragma once

namespace sdk {
	namespace structs {
		struct int_rect {
			int x0;
			int y0;
			int x1;
			int y1;
		};
	};
};